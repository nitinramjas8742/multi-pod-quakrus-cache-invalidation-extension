#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"
chmod +x gradlew

./gradlew build -x test --console=plain
./gradlew publishToMavenLocal --console=plain

echo
echo "Installed to ~/.m2/repository:"
echo "  com.example:redis-cache-runtime:1.1.1"
echo "  com.example:redis-cache-deployment:1.1.1"
echo
echo "Add to any Quarkus project:"
echo "  repositories { mavenLocal(); mavenCentral() }"
echo "  implementation 'com.example:redis-cache-runtime:1.1.1'"
