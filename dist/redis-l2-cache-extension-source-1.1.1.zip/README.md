﻿# Redis L2 Cache Extension (standalone source)

A Quarkus extension that gives Hibernate's second-level cache cross-pod
invalidation through Redis.

Each application pod keeps a local cache. Redis stores per-key version counters
and per-region epoch counters. A write on any pod bumps the counter, and other
pods evict their local entry on their next read. Redis failures fail closed:
reads go to the database instead of serving possibly stale data.

Both `READ_WRITE` and `NONSTRICT_READ_WRITE` are supported (1.1.1+). `READ_WRITE`
regions use the same version protocol, so they are coherent on the next read;
the extension does not perform Hibernate's cluster-wide soft locking.

Cache keys are tenant-scoped when Hibernate multitenancy is enabled, so two
tenants with the same entity id never share an invalidation counter (1.1.1+).
Without multitenancy the original key format is used unchanged, so the same
drop-in works for single-tenant and multi-tenant deployments.

## Requirements

* Java 21
* Quarkus 3.37.0 / Hibernate ORM 7.4.1 (rebuild against another version if needed)
* Redis reachable from every application pod

## Install on this machine

Open this folder in IntelliJ (it is a complete Gradle project) or run:

```powershell
# Windows
.\gradlew build -x test --console=plain
.\gradlew publishToMavenLocal --console=plain
```

```bash
# macOS / Linux
./gradlew build -x test --console=plain
./gradlew publishToMavenLocal --console=plain
```

Or run `install.ps1` / `install.sh`.

This publishes two artifacts to your local Maven repository
(`~/.m2/repository`):

```
com.example:redis-cache-runtime:1.1.1
com.example:redis-cache-deployment:1.1.1
```

You only ever declare the **runtime** artifact. Quarkus finds the deployment
artifact automatically through the runtime jar's
`META-INF/quarkus-extension.properties` descriptor.

## Use in any Quarkus project on this machine

**1. Add the local repository and dependency** (`build.gradle`):

```gradle
repositories {
    mavenLocal()
    mavenCentral()
}

dependencies {
    implementation 'com.example:redis-cache-runtime:1.1.1'
}
```

Kotlin DSL:

```kotlin
repositories {
    mavenLocal()
    mavenCentral()
}

dependencies {
    implementation("com.example:redis-cache-runtime:1.1.1")
}
```

**2. Enable second-level caching and configure Redis**
(`src/main/resources/application.properties`):

```properties
quarkus.hibernate-orm.second-level-caching-enabled=true
quarkus.redis.hosts=redis://localhost:6379
```

**3. Mark the entities/collections you want cached:**

```java
@Entity
@Cacheable
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
public class Customer {
    // ...

    @Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
    @ElementCollection
    public List<String> tags = new ArrayList<>();
}
```

`READ_WRITE` and `NONSTRICT_READ_WRITE` both work. `TRANSACTIONAL` and
`READ_ONLY` are not supported. Prefer `READ_WRITE` unless you deliberately want
the weaker consistency of `NONSTRICT_READ_WRITE`.

**4. Confirm it loaded.** Startup must contain:

```
Installed features: [..., redis-l2-cache, ...]
>>> Initializing MyCustomRegionFactory with Redis version/epoch invalidation <<<
```

**5. Test with two pods:** warm both, update on pod A, read on pod B, delete on
pod A, confirm 404 on pod B.

## Using it on another machine or in a team

`mavenLocal()` only works on the machine where you ran `publishToMavenLocal`.
For a team or CI, publish the two artifacts to your company
Nexus/Artifactory and use that repository URL instead of `mavenLocal()`.

The full hand-off bundle (from the POC repository) additionally contains a
ready-to-use Maven repository zip and organisation-wide instructions in
`HANDOFF.md` and `README-L2CACHE.md`.

## Constraints

* Only Hibernate-managed writes invalidate. Native SQL, bulk JPQL, other
  services writing the same tables, and direct DB changes bypass the protocol.
* Only Quarkus's default persistence unit (`<default>`) is supported.
* Query cache is not part of this design; list queries still hit the database.
* Each cache read costs one synchronous Redis `MGET`.
* Writes during a Redis outage can lose their invalidation until local entries
  expire (10 minutes). Reads during an outage fall back to the database.
* Do not combine with another second-level cache region factory on the same
  persistence unit.
* If multiple applications share one Redis, isolate them (logical database or
  separate instance) to avoid region-name collisions.
* Multi-tenancy: local cache keys already include the tenant, and Redis version
  keys add the Hibernate tenant id (`l2c:<region>:v:<tenant>:<key>`), so tenants
  do not invalidate each other. Without multitenancy the original
  `l2c:<region>:v:<key>` format is used unchanged. The region epoch is shared,
  so a region clear evicts every tenant (conservative, never stale).
* Keep Hibernate's default cache keys factory. A custom
  `hibernate.cache.keys_factory` that drops the tenant would also break
  Hibernate's own local cache isolation.
* `READ_WRITE` here means "coherent on the next read"; it is not Hibernate's
  cluster-wide soft-locking `READ_WRITE`. Use a lock-backed cache if you need
  that.

## Layout

```
redis-cache-runtime/       runtime code (shipped in the application)
redis-cache-deployment/    build-time wiring (used only during the Quarkus build)
settings.gradle            Gradle project definition
install.ps1 / install.sh   build + publishToMavenLocal helpers
```

If you vendor these modules into an existing multi-module build, adjust the
project path in `redis-cache-deployment/build.gradle`
(`project(':redis-cache-runtime')`) to match your layout.

