$ErrorActionPreference = 'Stop'
Push-Location $PSScriptRoot
try {
    & .\gradlew.bat build -x test --console=plain
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

    & .\gradlew.bat publishToMavenLocal --console=plain
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

    Write-Host ""
    Write-Host "Installed to $env:USERPROFILE\.m2\repository:" -ForegroundColor Green
    Write-Host "  com.example:redis-cache-runtime:1.1.1"
    Write-Host "  com.example:redis-cache-deployment:1.1.1"
    Write-Host ""
    Write-Host "Add to any Quarkus project:"
    Write-Host "  repositories { mavenLocal(); mavenCentral() }"
    Write-Host "  implementation 'com.example:redis-cache-runtime:1.1.1'"
} finally {
    Pop-Location
}
